<?php

namespace App\Services;

use App\Models\Post;
use App\Models\User;
use App\Models\Feed;
use App\Models\Follow;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redis;
use App\Jobs\PushPostToFeeds;
use App\Jobs\GenerateFeedJob;

class FeedService
{
    /**
     * Create a new post and trigger distribution
     */
    public function createPost(User $user, array $data)
    {
        $post = Post::create([
            'user_id' => $user->id,
            'content' => $data['content'],
            'image_url' => $data['image_url'] ?? null,
            'type' => $data['type'] ?? 'memory',
            'visibility' => $data['visibility'] ?? 'public',
            'is_anonymous' => $data['is_anonymous'] ?? false,
        ]);

        // We no longer push directly to Feed table as we use precomputed Redis feeds.
        // Instead, we just invalidate the user's feed cache and trigger a regeneration.
        
        Redis::del("feed:user:{$user->id}");
        GenerateFeedJob::dispatch($user->id);

        // Tell followers to regenerate their feeds
        $followerIds = $user->followers()->pluck('follower_id');
        foreach ($followerIds as $followerId) {
            Redis::del("feed:user:{$followerId}");
            GenerateFeedJob::dispatch($followerId);
        }

        return $post;
    }

    /**
     * Legacy Fan-out (Kept for compatibility, but basically unused now)
     */
    public function distributePost(Post $post)
    {
        // Handled by GenerateFeedJob now
        Log::info("Post {$post->id} distributed via GenerateFeedJob.");
    }

    /**
     * Get feed for a user using Precomputed Redis Lists
     */
    public function getFeed(User $user, int $perPage = 20)
    {
        $redisKey = "feed:user:{$user->id}";
        
        // Cek Redis list
        $postIds = Redis::lrange($redisKey, 0, $perPage - 1);
        
        if (empty($postIds)) {
            // Generate immediately for first time/expired
            // Optionally, we could dispatch and return fallback, but for UX let's fallback to basic query then dispatch
            GenerateFeedJob::dispatch($user->id);
            
            // Fallback while generating
            $posts = Post::where('visibility', 'public')
                ->where('user_id', '!=', $user->id)
                ->with(['user', 'likes', 'comments'])
                ->latest()
                ->limit($perPage)
                ->get();
                
            return $posts;
        }

        // Ambil post dari database berdasar urutan ID di Redis
        $posts = Post::whereIn('id', $postIds)
            ->with(['user', 'likes', 'comments'])
            ->get();

        // Restore urutan sesuai array ID dari Redis
        $sortedPosts = $posts->sortBy(function($post) use ($postIds) {
            return array_search($post->id, $postIds);
        })->values();

        return $sortedPosts;
    }

    /**
     * Toggle Follow/Unfollow
     */
    public function toggleFollow(User $follower, User $target)
    {
        if ($follower->id === $target->id) return false;

        $existing = Follow::where('follower_id', $follower->id)
            ->where('following_id', $target->id)
            ->first();

        if ($existing) {
            $existing->delete();
            
            // Trigger feed regeneration
            GenerateFeedJob::dispatch($follower->id);
            
            return ['status' => 'unfollowed'];
        }

        Follow::create([
            'follower_id' => $follower->id,
            'following_id' => $target->id,
        ]);
        
        // Trigger feed regeneration
        GenerateFeedJob::dispatch($follower->id);

        return ['status' => 'followed'];
    }
}
