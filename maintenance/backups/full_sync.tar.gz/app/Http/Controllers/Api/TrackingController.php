<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\UserPostView;
use App\Models\UserPostViewSummary;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TrackingController extends Controller
{
    public function view(Request $request)
    {
        $request->validate([
            'post_id' => 'required|exists:posts,id',
            'view_time' => 'required|integer|min:1000', // min 1 second
            'scroll_depth' => 'nullable|integer|min:0|max:100',
        ]);

        $userId = auth()->id();
        $postId = $request->post_id;
        $viewTime = $request->view_time;

        // 1. Log Raw Data
        UserPostView::create([
            'user_id' => $userId,
            'post_id' => $postId,
            'view_time' => $viewTime,
            'scroll_depth' => $request->scroll_depth,
        ]);

        // 2. Update Summary (Aggregation)
        UserPostViewSummary::updateOrInsert(
            ['user_id' => $userId, 'post_id' => $postId],
            [
                'total_view_time' => DB::raw("total_view_time + $viewTime"),
                'views_count' => DB::raw('views_count + 1'),
                'updated_at' => now(),
            ]
        );

        return response()->json(['status' => 'success']);
    }
}
