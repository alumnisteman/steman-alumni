<?php

namespace App\Services;

use App\Models\Post;
use App\Models\User;
use App\Models\UserInterest;
use App\Models\Like;
use App\Models\Comment;

class RankingService
{
    /**
     * Calculate heuristic score for a post regarding a specific user.
     */
    public function score(Post $post, User $user)
    {
        // 1. Engagement Score (25%)
        $engagement = ($post->likes_count * 2) + ($post->comments_count * 3);

        // 2. Relationship Score (25%)
        $relationship = $this->relationshipScore($user->id, $post->user_id);

        // 3. Content Score (20%)
        $content = $this->contentScore($user, $post);

        // 4. Dwell Time Score (25%)
        $dwell = $this->dwellTimeScore($user->id, $post->id);

        // 5. Recency Score (5%)
        $minutesAgo = max(1, now()->diffInMinutes($post->created_at));
        $recency = $minutesAgo < 60 ? 10 : (100 / $minutesAgo);

        // Calculate final weighted score
        return ($engagement * 0.25) + ($relationship * 0.25) + ($content * 0.2) + ($dwell * 0.25) + ($recency * 0.05);
    }

    private function dwellTimeScore($userId, $postId)
    {
        $summary = \App\Models\UserPostViewSummary::where('user_id', $userId)
            ->where('post_id', $postId)
            ->first();

        if (!$summary) return 0;

        // Normalize: 10 seconds = 10 points (max)
        return min($summary->total_view_time / 1000, 10);
    }

    private function relationshipScore($userId, $authorId)
    {
        if ($userId === $authorId) {
            return 0; // Prevent self-bias
        }

        $likes = Like::where('user_id', $userId)
            ->whereHas('post', function ($q) use ($authorId) {
                $q->where('user_id', $authorId);
            })
            ->count();

        $comments = Comment::where('user_id', $userId)
            ->where('commentable_type', Post::class)
            ->whereHasMorph('commentable', [Post::class], function ($q) use ($authorId) {
                $q->where('user_id', $authorId);
            })
            ->count();

        $storyViews = \App\Models\StoryView::where('viewer_id', $userId)
            ->whereHas('story', function ($q) use ($authorId) {
                $q->where('user_id', $authorId);
            })
            ->count();

        return ($likes * 2) + ($comments * 3) + ($storyViews * 5);
    }

    private function contentScore(User $user, Post $post)
    {
        $category = $post->type ?? 'general';
        
        $interest = UserInterest::where('user_id', $user->id)
            ->where('category', $category)
            ->value('score') ?? 0;

        return $interest;
    }
}
