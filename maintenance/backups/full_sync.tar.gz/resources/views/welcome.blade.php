@extends('layouts.app')

@section('content')
<style>
    /* Metode Letterbox Presisi: Terpusat & Utuh 100% */
    .hero-section.hero-banner-bg {
        position: relative;
        width: 100%;
        min-height: 500px;
        overflow: hidden;
        background-color: #0f172a; /* Slate dark background */
        display: flex;
        align-items: center;
        justify-content: center;
        box-sizing: border-box;
    }

    /* Penjaga Rasio 1280x670 */
    @media (min-width: 992px) {
        .hero-section.hero-banner-bg {
            aspect-ratio: 1280 / 600 !important;
            min-height: auto;
        }
    }

    .hero-main-img {
        width: 100%;
        height: 100%;
        object-fit: cover !important;
        object-position: center center !important;
        position: absolute;
        inset: 0;
        z-index: 1;
        display: block;
        filter: brightness(0.7) contrast(1.1); /* Auto-enhance image */
        transition: transform 0.5s ease-out;
    }

    .hero-content-overlay {
        position: absolute;
        inset: 0;
        z-index: 10;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.3) 0%, rgba(15, 23, 42, 0.8) 100%);
    }

    .glass-hero-card {
        background: rgba(255, 255, 255, 0.03);
        backdrop-filter: blur(12px); /* Efek Kaca Premium */
        -webkit-backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.15);
        padding: 3.5rem;
        border-radius: 32px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
        animation: float 6s ease-in-out infinite; /* Animasi Melayang */
    }

    @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-15px); }
        100% { transform: translateY(0px); }
    }
</style>

@push('styles')
    <link rel="preload" as="image" href="/storage/uploads/settings/hero.webp">
@endpush

<!-- Hero Section -->
<div class="hero-section text-center text-white hero-banner-bg">
    
    <!-- Layer 1: Main Image Cover -->
    <img
        src="{{ setting('hero_background', '/storage/uploads/settings/hero.webp') }}"
        width="1200"
        height="600"
        loading="eager"
        fetchpriority="high"
        decoding="async"
        class="hero-main-img"
        alt="Alumni Steman">

    <!-- Layer 2: Konten Text Overlay -->
    <div class="hero-content-overlay">
        <div class="container py-4">
            <div class="glass-hero-card animate__animated animate__fadeInUp">
                <div class="badge-hero mb-4 rounded-pill">Official Alumni Portal</div>
                <h1 class="display-4 display-md-2 fw-black mb-4 hero-title text-uppercase" style="letter-spacing: -1px;">{!! nl2br(e(setting('hero_title', "PENGURUS PUSAT\nIKATAN ALUMNI SMKN 2"))) !!}</h1>
                <p class="lead fw-medium mb-5 opacity-90 hero-subtitle mx-auto px-3" style="max-width: 800px; color: #cbd5e1;">{{ setting('hero_subtitle', 'MENJALIN JEJARING, MEMBANGUN KONTRIBUSI.') }}</p>
                <div class="d-flex flex-column flex-md-row justify-content-center gap-3 gap-md-4 mt-2 px-4 px-md-0">
                    <a href="/register" class="btn btn-warning border-0 fw-bold px-5 py-3 rounded-pill shadow-lg hover-lift">JOIN NOW <i class="bi bi-arrow-right ms-2"></i></a>
                    <a href="/alumni" class="btn btn-outline-light fw-bold px-5 py-3 rounded-pill hover-lift">DIRECTORY</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chairman Section -->
<div class="py-4 py-md-5" style="background-color: #f8fafc;">
    <div class="container py-2 py-md-4">
        <div class="row align-items-center g-5">
            <div class="col-lg-4 text-center">
                <div class="position-relative d-inline-block">
                     <img src="{{ setting('chairman_photo', 'https://ui-avatars.com/api/?name=Ketua+Umum&background=ffcc00&color=000&size=400') }}" 
                          onerror="this.src='https://ui-avatars.com/api/?name=Ketua+Umum&background=ffcc00&color=000&size=400'"
                          class="img-fluid rounded-4 shadow-lg border border-5 border-white" 
                          style="aspect-ratio: 3/4; height: 280px; width: 100%; max-width: 210px; object-fit: cover; object-position: top;" 
                          alt="Ketua Umum">
                    <div class="position-absolute bottom-0 start-50 translate-middle-x mb-n3">
                        <span class="badge bg-warning text-dark px-4 py-2 rounded-pill shadow-sm fw-bold">KETUA UMUM</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <h6 class="text-primary fw-bold text-uppercase mb-2">Sambutan Ketua Umum</h6>
                <h2 class="fw-bold mb-4 font-heading">{{ setting('chairman_name', 'Nama Ketua Umum') }}</h2>
                <div class="lead text-muted mb-4 italic" style="font-size: 1.1rem; line-height: 1.8;">
                    "{!! nl2br(e(setting('chairman_message', 'Selamat datang di portal resmi Ikatan Alumni SMKN 2 Ternate. Mari kita jalin silaturahmi dan berkontribusi bersama untuk almamater.'))) !!}"
                </div>
                <p class="fw-bold text-dark mb-0">Periode Jabatan:</p>
                <p class="text-muted">{{ setting('chairman_period', '2024 - 2028') }}</p>
            </div>
        </div>
    </div>
</div>

<!-- Visi & Misi Section with Shadcn-style Cards -->
<div class="py-20 bg-white">
    <div class="container">
        <div class="text-center mb-16">
            <h2 class="text-3xl md:text-5xl font-black mb-4">Misi & Visi Kami</h2>
            <div class="w-20 h-1.5 bg-yellow-400 mx-auto rounded-full"></div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 px-4">
            <x-ui.card class="p-4 border-none shadow-xl bg-slate-50 hover:shadow-2xl transition-all duration-300">
                <x-ui.card-header>
                    <div class="w-16 h-16 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mb-4">
                        <i class="bi bi-eye-fill text-3xl"></i>
                    </div>
                    <x-ui.card-title class="text-3xl font-black">VISI KAMI</x-ui.card-title>
                </x-ui.card-header>
                <x-ui.card-content>
                    <p class="text-slate-600 text-lg leading-relaxed italic">
                        "{!! nl2br(e(setting('vision', 'Menjadi wadah alumni yang solid, inovatif, dan berkontribusi nyata bagi almamater serta masyarakat luas.'))) !!}"
                    </p>
                </x-ui.card-content>
            </x-ui.card>

            <x-ui.card class="p-4 border-none shadow-xl bg-white hover:shadow-2xl transition-all duration-300 border-t-4 border-yellow-400">
                <x-ui.card-header>
                    <div class="w-16 h-16 bg-yellow-100 text-yellow-600 rounded-2xl flex items-center justify-center mb-4">
                        <i class="bi bi-bullseye text-3xl"></i>
                    </div>
                    <x-ui.card-title class="text-3xl font-black">MISI UTAMA</x-ui.card-title>
                </x-ui.card-header>
                <x-ui.card-content>
                    <div class="text-slate-600 text-lg leading-relaxed">
                        {!! nl2br(e(setting('mission', "1. Menjalin komunikasi antar alumni di seluruh penjuru dunia.\n2. Memberikan beasiswa dan dukungan karir bagi lulusan baru.\n3. Berkontribusi dalam pengembangan sarana dan prasarana sekolah."))) !!}
                    </div>
                    <div class="mt-8">
                        <x-ui.button variant="outline" class="rounded-full px-8 border-slate-200">
                            Selengkapnya
                        </x-ui.button>
                    </div>
                </x-ui.card-content>
            </x-ui.card>
        </div>
    </div>
</div>


<!-- Event Leadership Duo Section (Chairman & Secretary) -->
<div class="bg-light py-4 py-md-5">
    <div class="container py-4 py-md-5">
        <div class="row g-5">
            <!-- 1. Ketua Panitia -->
            <div class="col-lg-6">
                <div class="h-100 bg-white p-4 p-md-5 rounded-4 shadow-sm border-top border-4 border-primary">
                    <div class="d-flex align-items-center mb-4">
                        <div class="position-relative me-4">
                            <img src="{{ setting('event_chairman_photo', 'https://ui-avatars.com/api/?name=Ketua+Panitia&background=007bff&color=fff&size=400') }}" 
                                 class="rounded-circle shadow-sm border border-3 border-white" 
                                 alt="Ketua Panitia"
                                 style="height: 100px; width: 100px; object-fit: cover;">
                            <div class="position-absolute bottom-0 start-50 translate-middle-x">
                                <span class="badge bg-primary text-white rounded-pill px-2 py-1 x-small shadow-sm">KETUA</span>
                            </div>
                        </div>
                        <div>
                            <h6 class="text-primary fw-bold text-uppercase mb-1" style="font-size: 0.8rem;">Sambutan Ketua Panitia</h6>
                            <h4 class="fw-bold mb-0">{{ setting('event_chairman_name', 'Nama Ketua Panitia') }}</h4>
                            <small class="text-muted">{{ setting('event_chairman_period', 'Event Organizers') }}</small>
                        </div>
                    </div>
                    <div class="message-content position-relative">
                        <i class="bi bi-quote fs-1 text-primary opacity-10 position-absolute top-0 start-0"></i>
                        <p class="text-muted mb-0 lh-lg" style="font-style: italic; position: relative; z-index: 1; padding-top: 10px;">
                            "{!! nl2br(e(setting('event_chairman_message', 'Pesan sambutan dalam rangka kegiatan alumni...'))) !!}"
                        </p>
                    </div>
                </div>
            </div>

            <!-- 2. Sekretaris Panitia -->
            <div class="col-lg-6">
                <div class="h-100 bg-white p-4 p-md-5 rounded-4 shadow-sm border-top border-4 border-success">
                    <div class="d-flex align-items-center mb-4">
                        <div class="position-relative me-4">
                            <img src="{{ setting('secretary_photo', 'https://ui-avatars.com/api/?name=Sekretaris&background=28a745&color=fff&size=400') }}" 
                                 class="rounded-circle shadow-sm border border-3 border-white" 
                                 alt="Sekretaris Panitia"
                                 style="height: 100px; width: 100px; object-fit: cover;">
                            <div class="position-absolute bottom-0 start-50 translate-middle-x">
                                <span class="badge bg-success text-white rounded-pill px-2 py-1 x-small shadow-sm">SEKRETARIS</span>
                            </div>
                        </div>
                        <div>
                            <h6 class="text-success fw-bold text-uppercase mb-1" style="font-size: 0.8rem;">Sambutan Sekretaris Panitia</h6>
                            <h4 class="fw-bold mb-0">{{ setting('secretary_name', 'Nama Sekretaris') }}</h4>
                            <small class="text-muted">{{ setting('secretary_period', 'Event Committee') }}</small>
                        </div>
                    </div>
                    <div class="message-content position-relative">
                        <i class="bi bi-quote fs-1 text-success opacity-10 position-absolute top-0 start-0"></i>
                        <p class="text-muted mb-0 lh-lg" style="font-style: italic; position: relative; z-index: 1; padding-top: 10px;">
                            "{!! nl2br(e(setting('secretary_message', 'Pesan sambutan sekretaris dalam rangka persiapan kegiatan alumni...'))) !!}"
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    </div>
</div>
<!-- Content Advertisement -->
<div class="container py-4 text-center pb-0">
    <x-ad-slot position="content" aspectRatio="1280/200" mobileAspectRatio="400/150" />
</div>

<!-- Global Alumni Network Map - THE NEURAL NETWORK -->
<div class="neural-network-section py-5 position-relative overflow-hidden">
    <!-- Cyber Background Elements -->
    <div class="cyber-grid"></div>
    <div class="glow-orb"></div>

    <div class="container py-4 py-md-5 position-relative" style="z-index: 2;">
        <div class="text-center mb-5">
            <div class="d-inline-flex align-items-center mb-3 bg-primary bg-opacity-10 px-4 py-2 rounded-pill border border-primary border-opacity-25">
                <span class="ai-pulse me-2"></span>
                <h6 class="text-primary fw-bold text-uppercase mb-0" style="letter-spacing: 2px;">Live Network Feed</h6>
            </div>
            <h2 class="fw-black mb-3 display-5 text-dark">EKSOSISTEM GLOBAL ALUMNI</h2>
            <div class="section-divider mx-auto mt-2"></div>
            <p class="text-muted mx-auto lead" style="max-width: 800px;">
                Algoritma kami memetakan jejak digital alumni di <span class="text-primary fw-bold">berbagai benua</span>. Dari instansi nasional hingga korporasi internasional, membangun <span class="text-dark fw-bold">Neural Network karir</span> terkuat di dunia.
            </p>
        </div>
        
        <div class="row g-4 mb-5">
            <div class="col-md-4">
                <div class="stat-glass-card">
                    <div class="d-flex align-items-center">
                        <div class="stat-icon bg-primary"><i class="bi bi-geo-alt-fill"></i></div>
                        <div>
                            <h3 class="fw-black mb-0">{{ $nationalCount + $internationalCount }}+</h3>
                            <small class="text-muted text-uppercase">Nodes Terverifikasi</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-glass-card border-warning">
                    <div class="d-flex align-items-center">
                        <div class="stat-icon bg-warning"><i class="bi bi-globe2"></i></div>
                        <div>
                            <h3 class="fw-black mb-0">{{ $internationalCount }}+</h3>
                            <small class="text-muted text-uppercase">Global Reach (Intl)</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-glass-card border-success">
                    <div class="d-flex align-items-center">
                        <div class="stat-icon bg-success"><i class="bi bi-cpu"></i></div>
                        <div>
                            <h3 class="fw-black mb-0">98%</h3>
                            <small class="text-muted text-uppercase">Career Match Rate</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="map-container-premium shadow-lg border border-4 border-white">
            <x-alumni-map 
                id="home-global-map" 
                :locations="$alumniLocations" 
                :nationalCount="$nationalCount" 
                :internationalCount="$internationalCount" 
                height="550px"
            />
            <div class="map-scanner"></div>
        </div>
    </div>
</div>

<style>
    .neural-network-section {
        background-color: #f8fafc;
    }

    /* Cyber Grid Background */
    .cyber-grid {
        position: absolute;
        inset: 0;
        background-image: linear-gradient(rgba(15, 23, 42, 0.03) 1px, transparent 1px),
                          linear-gradient(90deg, rgba(15, 23, 42, 0.03) 1px, transparent 1px);
        background-size: 50px 50px;
        z-index: 1;
    }

    .glow-orb {
        position: absolute;
        width: 600px;
        height: 600px;
        background: radial-gradient(circle, rgba(59, 130, 246, 0.05) 0%, transparent 70%);
        top: 20%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 1;
    }

    .stat-glass-card {
        background: white;
        padding: 1.5rem;
        border-radius: 20px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05);
        transition: all 0.3s ease;
    }
    .stat-glass-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 35px -10px rgba(0,0,0,0.1);
    }

    .stat-icon {
        width: 50px;
        height: 50px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        margin-right: 1rem;
        font-size: 1.5rem;
    }

    .map-container-premium {
        position: relative;
        z-index: 10;
    }

    /* Scanner Effect */
    .map-scanner {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 5px;
        background: linear-gradient(to right, transparent, #3b82f6, transparent);
        box-shadow: 0 0 20px #3b82f6;
        animation: scan 4s linear infinite;
        z-index: 20;
        opacity: 0.5;
        pointer-events: none;
    }

    @keyframes scan {
        0% { top: 0; opacity: 0; }
        10% { opacity: 0.5; }
        90% { opacity: 0.5; }
        100% { top: 100%; opacity: 0; }
    }

    .ai-pulse {
        width: 10px;
        height: 10px;
        background-color: #3b82f6;
        border-radius: 50%;
        box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7);
        animation: ai-pulse 2s infinite;
    }

    @keyframes ai-pulse {
        0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7); }
        70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(59, 130, 246, 0); }
        100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(59, 130, 246, 0); }
    }
</style>

<!-- AI Insights Section - Futuristic Shadcn Style -->
<div class="py-24 bg-slate-950 text-white relative overflow-hidden">
    <!-- Background Decor -->
    <div class="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"></div>
    <div class="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl"></div>

    <div class="container relative z-10">
        <div class="flex flex-col md:flex-row items-center justify-between mb-16 gap-8">
            <div class="max-w-2xl">
                <div class="inline-flex items-center gap-3 bg-white/5 border border-white/10 px-4 py-2 rounded-full mb-6">
                    <span class="relative flex h-3 w-3">
                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
                        <span class="relative inline-flex rounded-full h-3 w-3 bg-yellow-500"></span>
                    </span>
                    <span class="text-yellow-500 font-bold text-xs uppercase tracking-widest">Smart Analytics</span>
                </div>
                <h2 class="text-4xl md:text-6xl font-black mb-6 tracking-tight">AI ALUMNI <span class="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">INSIGHTS</span></h2>
                <p class="text-slate-400 text-lg md:text-xl leading-relaxed">Algoritma cerdas kami menganalisis big data alumni untuk memprediksi tren kolaborasi dan arah industri masa depan.</p>
            </div>
            <div class="hidden lg:block">
                <x-ui.button variant="outline" class="border-white/10 text-white hover:bg-white/10 rounded-full px-8">
                    View Methodology
                </x-ui.button>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            @foreach($aiInsights as $key => $insight)
                <x-ui.card class="bg-white/5 border-white/10 hover:bg-white/10 transition-all duration-500 group">
                    <x-ui.card-header>
                        <div class="flex justify-between items-start w-full">
                            <div class="w-14 h-14 bg-yellow-500/10 text-yellow-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-500">
                                <i class="bi {{ $insight['icon'] }} text-2xl"></i>
                            </div>
                            <div class="text-right">
                                <span class="text-[10px] text-slate-500 uppercase font-bold block mb-1">Confidence</span>
                                <span class="text-yellow-500 font-black">{{ $insight['confidence'] }}</span>
                            </div>
                        </div>
                    </x-ui.card-header>
                    <x-ui.card-content>
                        <x-ui.card-title class="text-xl font-bold mb-4 text-white">{{ $insight['title'] }}</x-ui.card-title>
                        <p class="text-slate-400 text-sm leading-relaxed">{{ $insight['description'] }}</p>
                    </x-ui.card-content>
                </x-ui.card>
            @endforeach
        </div>
    </div>
</div>

<style>
    .ai-card { transition: all 0.3s ease; border: 1px solid rgba(255,255,255,0.1) !important; }
    .ai-card:hover { 
        transform: translateY(-10px); 
        background-color: rgba(255,255,255,0.15) !important;
        border-color: rgba(255,193,7,0.4) !important;
    }
    .pulse-container { position: relative; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; }
    .pulse-ring {
        position: absolute;
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background: #ffc107;
        animation: pulse-ring 2s cubic-bezier(0.25, 1, 0.5, 1) infinite;
    }
    @keyframes pulse-ring {
        0% { transform: scale(.33); opacity: 1; }
        80%, 100% { transform: scale(1.5); opacity: 0; }
    }
</style>

<!-- News Section -->
<div class="container py-4 py-md-5 mt-2 mt-md-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-end mb-4 gap-3">
        <div>
            <h2 class="fw-black mb-0">BERITA TERBARU</h2>
            <p class="text-muted small">Update info kegiatan alumni</p>
        </div>
        <a href="/news" class="btn btn-primary btn-sm rounded-pill px-4">Lihat Semua</a>
    </div>
    <div class="row g-4">
        <div class="col-lg-9">
            <div class="row g-4">
                @forelse($latestNews as $item)
                    <div class="col-md-6 col-lg-4">
                        <div class="card border-0 shadow-sm h-100 rounded-4 overflow-hidden hover-lift">
                            <img src="{{ $item->thumbnail ?? 'https://dummyimage.com/400x250' }}" class="card-img-top" style="height: 200px; object-fit: cover;" alt="{{ $item->title }}" loading="lazy">
                            <div class="card-body p-4">
                                <small class="text-primary fw-bold d-block mb-2">{{ $item->created_at->format('d M Y') }}</small>
                                <h5 class="fw-bold mb-3"><a href="/news/{{ $item->slug }}" class="text-dark text-decoration-none hover-text-primary">{{ $item->title }}</a></h5>
                                <p class="text-muted small mb-0">{{ \Illuminate\Support\Str::limit(strip_tags($item->content), 90) }}</p>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="col-12 text-center py-5">
                        <p class="text-muted">Belum ada berita terbaru.</p>
                    </div>
                @endforelse
            </div>
        </div>
        <div class="col-lg-3">
            <div class="sticky-top" style="top: 100px; z-index: 1;">
                <h6 class="fw-bold mb-3 text-uppercase small text-muted">Sponsor</h6>
                <x-ad-slot position="sidebar" aspectRatio="1/1" />
            </div>
        </div>
    </div>
</div>

<!-- Loker Section -->
<div class="bg-light py-4 py-md-5">
    <div class="container py-2 py-md-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-end mb-4 gap-3">
            <div>
                <h2 class="fw-black mb-0">LOWONGAN KERJA</h2>
                <p class="text-muted small">Peluang karir khusus alumni</p>
            </div>
            <a href="/jobs" class="btn btn-outline-primary btn-sm rounded-pill px-4">Cek Semua Loker</a>
        </div>
        <div class="row g-4">
            @forelse($latestJobs ?? [] as $job)
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm rounded-4 p-4 h-100 hover-lift">
                        <div class="d-flex align-items-start gap-3">
                            <div class="bg-primary bg-opacity-10 text-primary p-3 rounded-4">
                                <i class="bi bi-briefcase-fill fs-3"></i>
                            </div>
                            <div class="flex-grow-1">
                                <div class="badge bg-secondary mb-2 rounded-pill">{{ $job->type }}</div>
                                <h5 class="fw-bold mb-1">{{ $job->title }}</h5>
                                <p class="text-muted small mb-3"><i class="bi bi-building me-1"></i> {{ $job->company }} | <i class="bi bi-geo-alt me-1"></i> {{ $job->location }}</p>
                                <a href="/jobs/{{ $job->slug }}" class="btn btn-link text-primary p-0 text-decoration-none fw-bold hover-translate-x">Lihat Detail <i class="bi bi-arrow-right ms-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-12 text-center py-4">
                    <p class="text-muted">Belum ada lowongan kerja tersedia.</p>
                </div>
            @endforelse
        </div>
    </div>
</div>

<!-- Gallery Section -->
<div class="container py-4 py-md-5 mt-2 mt-md-4">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-end mb-4 gap-3">
        <div>
            <h2 class="fw-black mb-0">GALERI STEMAN</h2>
            <p class="text-muted small">Moment kebersamaan alumni</p>
        </div>
        <a href="/gallery" class="btn btn-outline-dark btn-sm rounded-pill px-4">Buka Galeri</a>
    </div>
    <div class="row g-3">
        @foreach($latestPhotos as $photo)
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm rounded-4 overflow-hidden h-100">
                    <img src="{{ $photo->file_path }}" class="card-img-top" style="height: 180px; object-fit: cover;" alt="{{ $photo->title }}" loading="lazy">
                </div>
            </div>
        @endforeach
    </div>
</div>

<!-- Success Stories / Hall of Fame -->
<div class="py-5" style="background-color: #fff;">
    <div class="container py-4">
        <div class="text-center mb-5">
            <h6 class="text-primary fw-bold text-uppercase mb-2">Inspirasi Steman</h6>
            <h2 class="fw-black mb-0">JEJAK SUKSES ALUMNI</h2>
            <div class="section-divider mx-auto mt-3"></div>
            <p class="text-muted mx-auto" style="max-width: 600px;">Kisah nyata perjuangan dan pencapaian alumni yang membanggakan almamater di kancah nasional maupun internasional.</p>
        </div>

        <div class="row g-4">
            @forelse($successStories as $story)
            <div class="col-md-4">
                <a href="{{ route('success-stories.show', $story->id) }}" class="text-decoration-none card-link h-100">
                    <div class="card h-100 border-0 shadow-lg rounded-4 overflow-hidden hover-lift success-card">
                        <div class="success-img-wrapper">
                            <img src="{{ $story->image_path ? asset('storage/'.$story->image_path) : 'https://ui-avatars.com/api/?name='.urlencode($story->name).'&background=ffcc00&color=000&size=500' }}" 
                                 class="card-img-top h-100" style="object-fit: cover;" alt="{{ $story->name }}">
                            <div class="success-overlay p-4">
                                <span class="badge bg-warning text-dark mb-2">{{ $story->title }}</span>
                                <h5 class="fw-bold text-white mb-0">{{ $story->name }}</h5>
                                <small class="text-white opacity-75">{{ $story->major_year }}</small>
                            </div>
                        </div>
                        <div class="card-body p-4 bg-white">
                            <p class="text-muted italic mb-0" style="font-size: 0.9rem;">"{{ \Illuminate\Support\Str::limit($story->quote, 120) }}"</p>
                        </div>
                    </div>
                </a>
            </div>
            @empty
            <div class="col-12 text-center py-5">
                <p class="text-muted">Belum ada kisah sukses yang ditonjolkan.</p>
            </div>
            @endforelse
        </div>
    </div>
</div>

<style>
    .card-link { display: block; }
    .success-card { transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
    .success-img-wrapper { position: relative; height: 320px; overflow: hidden; }
    .success-overlay {
        position: absolute;
        bottom: 0; left: 0; right: 0;
        background: linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.3) 50%, transparent 100%);
        z-index: 2;
    }
    .success-card:hover { transform: translateY(-15px); }
</style>

<!-- Join Section -->
<div class="join-section text-white py-5 mt-5">
    <div class="container py-5 text-center">
        <h2 class="display-5 fw-black mb-4" style="color: #ffcc00; text-shadow: 0 10px 20px rgba(0,0,0,0.3);">BELUM TERGABUNG?</h2>
        <p class="lead mb-5 opacity-75 mx-auto" style="max-width: 800px;">Mari perkuat jaringan alumni {{ setting('school_name', 'SMKN 2 Ternate') }}. Daftarkan diri Anda sekarang untuk mendapatkan info lowongan kerja, networking, dan program pengembangan diri lainnya.</p>
        <a href="/register" class="btn btn-warning border-0 fw-bold px-5 py-3 rounded-pill shadow-lg hover-lift">GABUNG SEKARANG</a>
    </div>
</div>

<style>
    .join-section {
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
        background-size: 200% 200%;
        animation: gradient-shift 15s ease infinite;
        position: relative;
        overflow: hidden;
    }

    @keyframes gradient-shift {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }

    .hover-lift {
        transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275), box-shadow 0.3s ease;
    }
    .hover-lift:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.4) !important;
    }
</style>

<style>
    .fw-black { font-weight: 900; }
    .hero-title { 
        letter-spacing: -2px; 
        line-height: 1;
        text-shadow: 2px 2px 20px rgba(0,0,0,0.5);
    }
    .badge-hero {
        background: #ffcc00;
        color: #000;
        display: inline-block;
        padding: 8px 20px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 2px;
        font-size: 0.75rem;
    }
    .btn-hero {
        background: #ffcc00;
        color: #000;
        transition: all 0.3s ease;
    }
    .btn-hero:hover {
        background: #e6b800;
        transform: translateY(-5px);
    }
    .btn-hero-outline {
        border: 2px solid #fff;
        transition: all 0.3s ease;
    }
    .btn-hero-outline:hover {
        background: #fff;
        color: #000;
        transform: translateY(-5px);
    }
    .shadow-hover { transition: transform 0.4s cubic-bezier(0.165, 0.84, 0.44, 1), box-shadow 0.4s ease; }
    .shadow-hover:hover { transform: translateY(-10px); box-shadow: 0 1.5rem 4rem rgba(0,0,0,.15)!important; }
    .font-heading { font-family: 'Inter', sans-serif; letter-spacing: -0.5px; }
    
    .section-divider {
        width: 60px;
        height: 4px;
        background: #ffcc00;
        margin-bottom: 2rem;
    }
</style>
@endsection
