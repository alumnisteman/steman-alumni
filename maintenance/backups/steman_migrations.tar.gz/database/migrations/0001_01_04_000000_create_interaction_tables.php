<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('comments')) {
            Schema::create('comments', function (Blueprint $table) {
                $table->id();
                $table->foreignId('user_id')->constrained()->onDelete('cascade');
                $table->morphs('commentable');
                $table->text('content');
                $table->timestamps();
                $table->softDeletes();
            });
        }

        if (!Schema::hasTable('likes')) {
            Schema::create('likes', function (Blueprint $table) {
                $table->id();
                $table->foreignId('user_id')->constrained()->onDelete('cascade');
                $table->morphs('likeable');
                $table->timestamps();

                $table->unique(['user_id', 'likeable_id', 'likeable_type']);
            });
        }

        if (!Schema::hasTable('tags')) {
            Schema::create('tags', function (Blueprint $table) {
                $table->id();
                $table->foreignId('tagged_user_id')->constrained('users')->onDelete('cascade');
                $table->morphs('taggable');
                $table->timestamps();

                $table->unique(['tagged_user_id', 'taggable_id', 'taggable_type'], 'idx_unique_tag');
            });
        }

        if (!Schema::hasTable('activity_logs')) {
            Schema::create('activity_logs', function (Blueprint $table) {
                $table->id();
                $table->foreignId('user_id')->nullable()->constrained()->onDelete('set null');
                $table->string('action');
                $table->text('description')->nullable();
                $table->string('ip_address', 45)->nullable();
                $table->text('user_agent')->nullable();
                $table->timestamps();
                
                $table->index('action');
            });
        }

        if (!Schema::hasTable('badges')) {
            Schema::create('badges', function (Blueprint $table) {
                $table->id();
                $table->foreignId('user_id')->constrained()->onDelete('cascade');
                $table->string('name');
                $table->string('icon')->nullable();
                $table->text('description')->nullable();
                $table->timestamp('awarded_at')->useCurrent();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('badges');
        Schema::dropIfExists('activity_logs');
        Schema::dropIfExists('tags');
        Schema::dropIfExists('likes');
        Schema::dropIfExists('comments');
    }
};
